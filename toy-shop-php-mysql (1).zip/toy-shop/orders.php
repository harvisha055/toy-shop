<?php
$page_title = 'My Orders';
require_once __DIR__ . '/includes/header.php';
require_login();

$cust_id = (int)$_SESSION['customer_id'];
$view_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($view_id > 0) {
    $res = mysqli_query($conn, "SELECT * FROM orders WHERE id = $view_id AND customer_id = $cust_id");
    $order = mysqli_fetch_assoc($res);
    if (!$order) redirect('orders.php');
    $items = mysqli_query($conn, "SELECT * FROM order_items WHERE order_id = $view_id");
    ?>
    <div class="container">
        <p><a href="orders.php">&larr; Back to orders</a></p>
        <h1>Order #<?php echo $order['id']; ?></h1>
        <p>Status: <span class="badge badge-<?php echo $order['status']; ?>"><?php echo $order['status']; ?></span></p>
        <p>Placed on <?php echo date('M d, Y', strtotime($order['created_at'])); ?></p>
        <p><strong>Ship to:</strong> <?php echo htmlspecialchars($order['shipping_name']); ?>, <?php echo htmlspecialchars($order['shipping_address']); ?>, <?php echo htmlspecialchars($order['shipping_phone']); ?></p>

        <table class="data-table">
            <thead><tr><th>Product</th><th>Price</th><th>Qty</th><th>Subtotal</th></tr></thead>
            <tbody>
            <?php while ($it = mysqli_fetch_assoc($items)): ?>
                <tr>
                    <td><?php echo htmlspecialchars($it['product_name']); ?></td>
                    <td><?php echo format_price($it['price']); ?></td>
                    <td><?php echo $it['quantity']; ?></td>
                    <td><?php echo format_price($it['price'] * $it['quantity']); ?></td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
        <div class="cart-summary">
            <div class="row total"><span>Total</span><span><?php echo format_price($order['total']); ?></span></div>
        </div>
    </div>
    <?php
} else {
    $orders = mysqli_query($conn, "SELECT * FROM orders WHERE customer_id = $cust_id ORDER BY created_at DESC");
    ?>
    <div class="container">
        <h1>My Orders</h1>
        <?php if (mysqli_num_rows($orders) === 0): ?>
            <p>You haven't placed any orders yet. <a href="index.php">Start shopping &rarr;</a></p>
        <?php else: ?>
        <table class="data-table">
            <thead><tr><th>Order #</th><th>Date</th><th>Total</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php while ($o = mysqli_fetch_assoc($orders)): ?>
                <tr>
                    <td>#<?php echo $o['id']; ?></td>
                    <td><?php echo date('M d, Y', strtotime($o['created_at'])); ?></td>
                    <td><?php echo format_price($o['total']); ?></td>
                    <td><span class="badge badge-<?php echo $o['status']; ?>"><?php echo $o['status']; ?></span></td>
                    <td><a class="btn small" href="orders.php?id=<?php echo $o['id']; ?>">View</a></td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
    <?php
}
require_once __DIR__ . '/includes/footer.php';
