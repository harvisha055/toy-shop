<footer class="site-footer">
    &copy; <?php echo date('Y'); ?> ToyBox. All rights reserved. | <a href="admin/login.php">Admin Login</a>
</footer>
</body>
</html>
