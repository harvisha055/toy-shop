<?php
require_once __DIR__ . '/../config/db.php';
require_once __DIR__ . '/../config/functions.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo isset($page_title) ? $page_title . ' — Toy Box' : 'Toy Box — Fun for Every Kid'; ?></title>
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header class="site-header">
    <div class="nav-wrap">
        <a href="index.php" class="logo">Toy<span>Box</span></a>
        <nav class="nav-links">
            <a href="index.php">Home</a>
            <a href="cart.php">Cart <span class="cart-badge"><?php echo cart_count(); ?></span></a>
            <?php if (is_logged_in()): ?>
                <a href="orders.php">My Orders</a>
                <a href="logout.php">Logout (<?php echo htmlspecialchars($_SESSION['customer_name']); ?>)</a>
            <?php else: ?>
                <a href="login.php">Login</a>
                <a href="register.php">Register</a>
            <?php endif; ?>
        </nav>
    </div>
</header>
