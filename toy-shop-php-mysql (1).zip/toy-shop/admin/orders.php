<?php
$page_title = 'Orders';
require_once __DIR__ . '/includes/header.php';

$status_filter = $_GET['status'] ?? '';
$sql = "SELECT o.*, c.name AS cust_name, c.email AS cust_email FROM orders o LEFT JOIN customers c ON o.customer_id = c.id";
if ($status_filter !== '') {
    $status_filter_safe = clean($status_filter);
    $sql .= " WHERE o.status = '$status_filter_safe'";
}
$sql .= " ORDER BY o.created_at DESC";
$orders = mysqli_query($conn, $sql);

$statuses = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];
?>

<div class="admin-topbar"><h1>Orders</h1></div>

<div class="category-bar">
    <a href="orders.php" class="<?php echo $status_filter === '' ? 'active' : ''; ?>">All</a>
    <?php foreach ($statuses as $s): ?>
        <a href="orders.php?status=<?php echo $s; ?>" class="<?php echo $status_filter === $s ? 'active' : ''; ?>"><?php echo ucfirst($s); ?></a>
    <?php endforeach; ?>
</div>

<table class="data-table">
    <thead><tr><th>Order #</th><th>Customer</th><th>Total</th><th>Status</th><th>Date</th><th></th></tr></thead>
    <tbody>
    <?php while ($o = mysqli_fetch_assoc($orders)): ?>
        <tr>
            <td>#<?php echo $o['id']; ?></td>
            <td><?php echo htmlspecialchars($o['cust_name']); ?><br><small style="color:#888;"><?php echo htmlspecialchars($o['cust_email']); ?></small></td>
            <td><?php echo format_price($o['total']); ?></td>
            <td><span class="badge badge-<?php echo $o['status']; ?>"><?php echo $o['status']; ?></span></td>
            <td><?php echo date('M d, Y', strtotime($o['created_at'])); ?></td>
            <td><a class="btn small" href="order_view.php?id=<?php echo $o['id']; ?>">View</a></td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
