<?php
$page_title = 'Customers';
require_once __DIR__ . '/includes/header.php';

$customers = mysqli_query($conn, "SELECT c.*, (SELECT COUNT(*) FROM orders o WHERE o.customer_id = c.id) AS order_count FROM customers c ORDER BY c.created_at DESC");
?>

<div class="admin-topbar"><h1>Customers</h1></div>

<table class="data-table">
    <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Orders</th><th>Joined</th></tr></thead>
    <tbody>
    <?php while ($c = mysqli_fetch_assoc($customers)): ?>
        <tr>
            <td><?php echo htmlspecialchars($c['name']); ?></td>
            <td><?php echo htmlspecialchars($c['email']); ?></td>
            <td><?php echo htmlspecialchars($c['phone']); ?></td>
            <td><?php echo $c['order_count']; ?></td>
            <td><?php echo date('M d, Y', strtotime($c['created_at'])); ?></td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
