<?php
$page_title = 'Products';
require_once __DIR__ . '/includes/header.php';

// Handle delete
if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    mysqli_query($conn, "DELETE FROM products WHERE id = $id");
    redirect('products.php');
}

$products = mysqli_query($conn, "SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id ORDER BY p.created_at DESC");
?>

<div class="admin-topbar">
    <h1>Products</h1>
    <a href="product_form.php" class="btn">+ Add Product</a>
</div>

<table class="data-table">
    <thead><tr><th>Image</th><th>Name</th><th>Category</th><th>Price</th><th>Stock</th><th>Active</th><th>Actions</th></tr></thead>
    <tbody>
    <?php while ($p = mysqli_fetch_assoc($products)): ?>
        <tr>
            <td><img src="../assets/uploads/<?php echo htmlspecialchars($p['image']); ?>" onerror="this.src='https://placehold.co/50x50?text=Toy'"></td>
            <td><?php echo htmlspecialchars($p['name']); ?></td>
            <td><?php echo htmlspecialchars($p['category_name'] ?? '—'); ?></td>
            <td><?php echo format_price($p['price']); ?></td>
            <td><?php echo $p['stock']; ?></td>
            <td><?php echo $p['is_active'] ? 'Yes' : 'No'; ?></td>
            <td>
                <a class="btn small" href="product_form.php?id=<?php echo $p['id']; ?>">Edit</a>
                <a class="btn small danger" href="products.php?delete=<?php echo $p['id']; ?>"
                   onclick="return confirm('Delete this product?');">Delete</a>
            </td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
