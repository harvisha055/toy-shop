<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../config/functions.php';
require_admin();

$current = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo isset($page_title) ? $page_title . ' — Admin' : 'Admin — ToyBox'; ?></title>
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<div class="admin-wrap">
    <aside class="admin-sidebar">
        <h2>ToyBox Admin</h2>
        <a href="dashboard.php" class="<?php echo $current === 'dashboard.php' ? 'active' : ''; ?>">Dashboard</a>
        <a href="products.php" class="<?php echo $current === 'products.php' || $current === 'product_form.php' ? 'active' : ''; ?>">Products</a>
        <a href="categories.php" class="<?php echo $current === 'categories.php' ? 'active' : ''; ?>">Categories</a>
        <a href="orders.php" class="<?php echo $current === 'orders.php' || $current === 'order_view.php' ? 'active' : ''; ?>">Orders</a>
        <a href="customers.php" class="<?php echo $current === 'customers.php' ? 'active' : ''; ?>">Customers</a>
        <a href="../index.php" target="_blank">View Store &rarr;</a>
        <a href="logout.php">Logout</a>
    </aside>
    <main class="admin-main">
