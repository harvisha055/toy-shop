<?php
$page_title = 'Order Detail';
require_once __DIR__ . '/includes/header.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $new_status = clean($_POST['status'] ?? 'pending');
    $stmt = mysqli_prepare($conn, "UPDATE orders SET status = ? WHERE id = ?");
    mysqli_stmt_bind_param($stmt, 'si', $new_status, $id);
    mysqli_stmt_execute($stmt);
    redirect('order_view.php?id=' . $id);
}

$res = mysqli_query($conn, "SELECT o.*, c.name AS cust_name, c.email AS cust_email FROM orders o LEFT JOIN customers c ON o.customer_id = c.id WHERE o.id = $id");
$order = mysqli_fetch_assoc($res);
if (!$order) redirect('orders.php');

$items = mysqli_query($conn, "SELECT * FROM order_items WHERE order_id = $id");
$statuses = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];
?>

<div class="admin-topbar">
    <h1>Order #<?php echo $order['id']; ?></h1>
    <a href="orders.php" class="btn outline">&larr; Back</a>
</div>

<p><strong>Customer:</strong> <?php echo htmlspecialchars($order['cust_name']); ?> (<?php echo htmlspecialchars($order['cust_email']); ?>)</p>
<p><strong>Ship to:</strong> <?php echo htmlspecialchars($order['shipping_name']); ?>, <?php echo htmlspecialchars($order['shipping_address']); ?>, <?php echo htmlspecialchars($order['shipping_phone']); ?></p>
<p><strong>Placed:</strong> <?php echo date('M d, Y H:i', strtotime($order['created_at'])); ?></p>

<form method="post" style="display:flex; gap:10px; align-items:center; margin:16px 0;">
    <label><strong>Status:</strong></label>
    <select name="status">
        <?php foreach ($statuses as $s): ?>
            <option value="<?php echo $s; ?>" <?php echo $order['status'] === $s ? 'selected' : ''; ?>><?php echo ucfirst($s); ?></option>
        <?php endforeach; ?>
    </select>
    <button class="btn small" type="submit">Update Status</button>
</form>

<table class="data-table">
    <thead><tr><th>Product</th><th>Price</th><th>Qty</th><th>Subtotal</th></tr></thead>
    <tbody>
    <?php while ($it = mysqli_fetch_assoc($items)): ?>
        <tr>
            <td><?php echo htmlspecialchars($it['product_name']); ?></td>
            <td><?php echo format_price($it['price']); ?></td>
            <td><?php echo $it['quantity']; ?></td>
            <td><?php echo format_price($it['price'] * $it['quantity']); ?></td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>

<div class="cart-summary">
    <div class="row total"><span>Total</span><span><?php echo format_price($order['total']); ?></span></div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
