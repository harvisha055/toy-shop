<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/functions.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$res = mysqli_query($conn, "SELECT p.*, c.name AS category_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.id = $id AND p.is_active = 1");
$product = mysqli_fetch_assoc($res);

if (!$product) {
    redirect('index.php');
}

$page_title = $product['name'];
require_once __DIR__ . '/includes/header.php';
?>

<div class="container">
    <p><a href="index.php">&larr; Back to shop</a></p>
    <div class="product-detail">
        <img src="assets/uploads/<?php echo htmlspecialchars($product['image']); ?>"
             onerror="this.src='https://placehold.co/400x400?text=Toy'" alt="<?php echo htmlspecialchars($product['name']); ?>">
        <div class="details">
            <p style="color:#888; font-weight:600;"><?php echo htmlspecialchars($product['category_name'] ?? 'Uncategorized'); ?></p>
            <h1><?php echo htmlspecialchars($product['name']); ?></h1>
            <div class="price"><?php echo format_price($product['price']); ?></div>
            <p><?php echo nl2br(htmlspecialchars($product['description'])); ?></p>
            <p class="stock"><?php echo $product['stock'] > 0 ? $product['stock'] . ' in stock' : 'Out of stock'; ?></p>

            <?php if ($product['stock'] > 0): ?>
            <form method="post" action="cart_action.php" style="display:flex; gap:10px; align-items:center; margin-top:16px;">
                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                <input type="hidden" name="action" value="add">
                <label>Qty:
                    <input class="qty-input" type="number" name="quantity" value="1" min="1" max="<?php echo $product['stock']; ?>">
                </label>
                <button class="btn" type="submit">Add to Cart</button>
            </form>
            <?php else: ?>
                <button class="btn" disabled>Out of Stock</button>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
