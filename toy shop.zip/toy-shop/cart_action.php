<?php
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/config/functions.php';

if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) {
    $_SESSION['cart'] = [];
}

$action = $_POST['action'] ?? '';
$product_id = isset($_POST['product_id']) ? (int)$_POST['product_id'] : 0;

if ($action === 'add' && $product_id > 0) {
    $qty = isset($_POST['quantity']) ? max(1, (int)$_POST['quantity']) : 1;
    if (!isset($_SESSION['cart'][$product_id])) {
        $_SESSION['cart'][$product_id] = 0;
    }
    $_SESSION['cart'][$product_id] += $qty;
} elseif ($action === 'update' && $product_id > 0) {
    $qty = max(0, (int)($_POST['quantity'] ?? 0));
    if ($qty <= 0) {
        unset($_SESSION['cart'][$product_id]);
    } else {
        $_SESSION['cart'][$product_id] = $qty;
    }
} elseif ($action === 'remove' && $product_id > 0) {
    unset($_SESSION['cart'][$product_id]);
} elseif ($action === 'clear') {
    $_SESSION['cart'] = [];
}

$redirect_to = $_POST['redirect'] ?? 'cart.php';
redirect($redirect_to);
