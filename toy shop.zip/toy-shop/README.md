# ToyBox — PHP & MySQL Toy Shop E-commerce Site

A simple, self-contained toy shop e-commerce project with a **customer storefront**
and a separate **admin panel**, built with plain PHP (mysqli) and MySQL — no
framework required.

## Features

**Customer side**
- Browse toys by category, search by keyword
- Product detail pages
- Session-based shopping cart (add / update qty / remove / clear)
- Customer registration & login (passwords hashed with bcrypt)
- Checkout with shipping details → creates an order, reduces stock
- Order history + order detail pages

**Admin side**
- Separate admin login (own `admins` table)
- Dashboard with key stats (products, orders, revenue, low stock)
- Product CRUD with image upload
- Category CRUD
- Order list with status filter + status updates (pending → processing → shipped → delivered / cancelled)
- Customer list

## Requirements
- PHP 7.4+ (works with 8.x)
- MySQL / MariaDB
- A local server stack such as **XAMPP**, **WAMP**, **MAMP**, or `php -S`

## Setup

1. **Create the database.**
   Open phpMyAdmin (or the MySQL CLI) and import `database.sql`. This creates
   the `toy_shop` database, all tables, sample products/categories, and a
   default admin account.

2. **Configure the DB connection.**
   Edit `config/db.php` and set your MySQL credentials:
   ```php
   define('DB_HOST', 'localhost');
   define('DB_USER', 'root');
   define('DB_PASS', '');
   define('DB_NAME', 'toy_shop');
   ```

3. **Place the project in your server's web root**, e.g. for XAMPP:
   `C:\xampp\htdocs\toy-shop\` (Windows) or `/Applications/XAMPP/htdocs/toy-shop/` (Mac).

4. **Make the uploads folder writable** (for product images):
   `assets/uploads/` — the admin product form uploads images here.

5. **Visit the site:**
   - Storefront: `http://localhost/toy-shop/`
   - Admin panel: `http://localhost/toy-shop/admin/login.php`

### Default admin login
```
Username: admin
Password: admin123
```
Change this password after first login (update the `admins` table with a new
bcrypt hash, e.g. via `password_hash()` in a small PHP snippet).

## Folder structure
```
toy-shop/
├── database.sql              # Import this first
├── config/
│   ├── db.php                 # DB credentials + session start
│   └── functions.php          # Shared helper functions
├── includes/                  # Customer-side header/footer
├── assets/
│   ├── css/style.css
│   └── uploads/                # Product images uploaded via admin
├── index.php                  # Storefront home / product listing
├── product.php                 # Product detail
├── cart.php / cart_action.php  # Cart page + add/update/remove logic
├── checkout.php                 # Checkout → creates order
├── order_success.php / orders.php
├── login.php / register.php / logout.php   # Customer auth
└── admin/
    ├── includes/                # Admin header/footer (sidebar nav)
    ├── login.php / logout.php   # Admin auth
    ├── dashboard.php
    ├── products.php / product_form.php
    ├── categories.php
    ├── orders.php / order_view.php
    └── customers.php
```

## Notes & next steps
- This project uses **mysqli with prepared statements** for all inputs that
  touch SQL to prevent SQL injection.
- Passwords are hashed with PHP's `password_hash()` / verified with
  `password_verify()`.
- Product images fall back to a placeholder if the uploaded file is missing.
- For production use, consider adding: CSRF tokens on forms, HTTPS, a
  payment gateway integration (Stripe/PayPal), pagination on product/order
  lists, and email notifications on order status changes.
