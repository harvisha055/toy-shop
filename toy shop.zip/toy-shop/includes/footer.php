<footer class="site-footer">
    &copy; <?php echo date('Y'); ?> ToyBox. All rights reserved. | <a href="admin/login.php">Admin Login</a>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
