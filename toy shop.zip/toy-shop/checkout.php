<?php
$page_title = 'Checkout';
require_once __DIR__ . '/includes/header.php';
require_login();

$cart = $_SESSION['cart'] ?? [];
if (empty($cart)) redirect('cart.php');

// Load customer defaults
$cust_res = mysqli_query($conn, "SELECT * FROM customers WHERE id = " . (int)$_SESSION['customer_id']);
$customer = mysqli_fetch_assoc($cust_res);

// Load cart items
$ids = implode(',', array_map('intval', array_keys($cart)));
$res = mysqli_query($conn, "SELECT * FROM products WHERE id IN ($ids)");
$items = [];
$grand_total = 0;
while ($p = mysqli_fetch_assoc($res)) {
    $qty = min($cart[$p['id']], $p['stock']); // can't exceed stock
    if ($qty <= 0) continue;
    $subtotal = $qty * $p['price'];
    $grand_total += $subtotal;
    $items[] = ['product' => $p, 'qty' => $qty, 'subtotal' => $subtotal];
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !empty($items)) {
    $name = clean($_POST['name'] ?? '');
    $address = clean($_POST['address'] ?? '');
    $phone = clean($_POST['phone'] ?? '');

    if ($name === '' || $address === '' || $phone === '') {
        $error = 'Please fill in all shipping details.';
    } else {
        mysqli_begin_transaction($conn);
        try {
            $stmt = mysqli_prepare($conn, "INSERT INTO orders (customer_id, total, shipping_name, shipping_address, shipping_phone, status) VALUES (?, ?, ?, ?, ?, 'pending')");
            $cust_id = $_SESSION['customer_id'];
            mysqli_stmt_bind_param($stmt, 'idsss', $cust_id, $grand_total, $name, $address, $phone);
            mysqli_stmt_execute($stmt);
            $order_id = mysqli_insert_id($conn);

            foreach ($items as $item) {
                $p = $item['product'];
                $stmt2 = mysqli_prepare($conn, "INSERT INTO order_items (order_id, product_id, product_name, price, quantity) VALUES (?, ?, ?, ?, ?)");
                mysqli_stmt_bind_param($stmt2, 'iisdi', $order_id, $p['id'], $p['name'], $p['price'], $item['qty']);
                mysqli_stmt_execute($stmt2);

                // reduce stock
                mysqli_query($conn, "UPDATE products SET stock = stock - {$item['qty']} WHERE id = {$p['id']} AND stock >= {$item['qty']}");
            }

            mysqli_commit($conn);
            $_SESSION['cart'] = [];
            redirect('order_success.php?id=' . $order_id);
        } catch (Exception $e) {
            mysqli_rollback($conn);
            $error = 'Something went wrong placing your order. Please try again.';
        }
    }
}
?>

<div class="container">
    <h1>Checkout</h1>
    <?php if ($error): ?><div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

    <div style="display:flex; gap:40px; flex-wrap:wrap;">
        <form method="post" class="form-box" style="flex:1; min-width:280px; margin:0;">
            <h2>Shipping Details</h2>
            <div class="form-group">
                <label>Full Name *</label>
                <input type="text" name="name" required value="<?php echo htmlspecialchars($customer['name']); ?>">
            </div>
            <div class="form-group">
                <label>Address *</label>
                <textarea name="address" required><?php echo htmlspecialchars($customer['address']); ?></textarea>
            </div>
            <div class="form-group">
                <label>Phone *</label>
                <input type="text" name="phone" required value="<?php echo htmlspecialchars($customer['phone']); ?>">
            </div>
            <button class="btn block" type="submit">Place Order</button>
        </form>

        <div class="cart-summary" style="flex:1; min-width:260px; margin-top:0;">
            <h2>Order Summary</h2>
            <?php foreach ($items as $item): ?>
                <div class="row">
                    <span><?php echo htmlspecialchars($item['product']['name']); ?> &times; <?php echo $item['qty']; ?></span>
                    <span><?php echo format_price($item['subtotal']); ?></span>
                </div>
            <?php endforeach; ?>
            <hr>
            <div class="row total"><span>Total</span><span><?php echo format_price($grand_total); ?></span></div>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
