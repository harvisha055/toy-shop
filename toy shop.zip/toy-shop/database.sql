-- ============================================
-- Toy Shop E-commerce Database
-- Import this file in phpMyAdmin / MySQL first
-- ============================================

CREATE DATABASE IF NOT EXISTS toy_shop CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE toy_shop;

-- ---------- Categories ----------
CREATE TABLE categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------- Products ----------
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL DEFAULT 0,
    stock INT NOT NULL DEFAULT 0,
    image VARCHAR(255) DEFAULT 'no-image.png',
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE SET NULL
);

-- ---------- Customers (user side accounts) ----------
CREATE TABLE customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    phone VARCHAR(20),
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------- Admins (admin side accounts) ----------
CREATE TABLE admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------- Orders ----------
CREATE TABLE orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    total DECIMAL(10,2) NOT NULL DEFAULT 0,
    shipping_name VARCHAR(100),
    shipping_address TEXT,
    shipping_phone VARCHAR(20),
    status ENUM('pending','processing','shipped','delivered','cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE
);

-- ---------- Order items ----------
CREATE TABLE order_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    order_id INT NOT NULL,
    product_id INT,
    product_name VARCHAR(150) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    quantity INT NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE,
    FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE SET NULL
);

-- ============================================
-- Seed data
-- ============================================

INSERT INTO categories (name) VALUES
('Action Figures'), ('Educational Toys'), ('Soft Toys'), ('Board Games'), ('Outdoor Toys');

INSERT INTO products (category_id, name, description, price, stock, image) VALUES
(1, 'Super Hero Action Figure', 'Poseable 6-inch super hero action figure with accessories.', 449.00, 50, 'no-image.png'),
(1, 'Robot Warrior Set', 'Transforming robot toy with light-up features.', 799.00, 30, 'no-image.png'),
(2, 'Alphabet Learning Blocks', 'Wooden blocks to help kids learn letters and numbers.', 599.00, 40, 'no-image.png'),
(2, 'Science Experiment Kit', 'Safe, fun chemistry set for young scientists.', 999.00, 25, 'no-image.png'),
(3, 'Cuddly Teddy Bear', 'Soft plush teddy bear, 14 inches tall.', 399.00, 60, 'no-image.png'),
(3, 'Bunny Plush Toy', 'Extra soft bunny plush, perfect for toddlers.', 349.00, 45, 'no-image.png'),
(4, 'Family Puzzle Game', '500-piece jigsaw puzzle for family game night.', 449.00, 35, 'no-image.png'),
(4, 'Strategy Board Game', 'Classic strategy board game for ages 8+.', 749.00, 20, 'no-image.png'),
(5, 'Bouncy Ball Set', 'Set of 5 colorful bouncy balls for outdoor play.', 249.00, 70, 'no-image.png'),
(5, 'Kids Bicycle Helmet', 'Safety helmet with adjustable straps.', 899.00, 15, 'no-image.png');

-- Default admin login: username = admin, password = admin123
-- (password hash below corresponds to 'admin123' using PHP password_hash/BCRYPT)
INSERT INTO admins (username, password) VALUES
('admin', '$2b$10$KTcDfFeeOuQDPYH0JL2OWOm31uSD8Ccbgi9j0gWuZZ85QSzaAyAMm');
