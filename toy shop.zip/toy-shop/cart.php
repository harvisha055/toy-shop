<?php
$page_title = 'Your Cart';
require_once __DIR__ . '/includes/header.php';

$cart = $_SESSION['cart'] ?? [];
$items = [];
$grand_total = 0;

if (!empty($cart)) {
    $ids = implode(',', array_map('intval', array_keys($cart)));
    $res = mysqli_query($conn, "SELECT * FROM products WHERE id IN ($ids)");
    while ($p = mysqli_fetch_assoc($res)) {
        $qty = $cart[$p['id']];
        $subtotal = $qty * $p['price'];
        $grand_total += $subtotal;
        $items[] = ['product' => $p, 'qty' => $qty, 'subtotal' => $subtotal];
    }
}
?>

<div class="container">
    <h1>Your Cart</h1>

    <?php if (empty($items)): ?>
        <p>Your cart is empty. <a href="index.php">Continue shopping &rarr;</a></p>
    <?php else: ?>
        <div class="table-responsive">
        <table class="data-table">
            <thead>
                <tr><th>Product</th><th>Price</th><th>Quantity</th><th>Subtotal</th><th></th></tr>
            </thead>
            <tbody>
                <?php foreach ($items as $item): $p = $item['product']; ?>
                <tr>
                    <td style="display:flex; align-items:center; gap:10px;">
                        <img src="assets/uploads/<?php echo htmlspecialchars($p['image']); ?>" onerror="this.src='https://placehold.co/60x60?text=Toy'">
                        <?php echo htmlspecialchars($p['name']); ?>
                    </td>
                    <td><?php echo format_price($p['price']); ?></td>
                    <td>
                        <form method="post" action="cart_action.php" style="display:flex; gap:6px;">
                            <input type="hidden" name="product_id" value="<?php echo $p['id']; ?>">
                            <input type="hidden" name="action" value="update">
                            <input class="qty-input" type="number" name="quantity" value="<?php echo $item['qty']; ?>" min="1" max="<?php echo $p['stock']; ?>">
                            <button class="btn small" type="submit">Update</button>
                        </form>
                    </td>
                    <td><?php echo format_price($item['subtotal']); ?></td>
                    <td>
                        <form method="post" action="cart_action.php">
                            <input type="hidden" name="product_id" value="<?php echo $p['id']; ?>">
                            <input type="hidden" name="action" value="remove">
                            <button class="btn small danger" type="submit">Remove</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        </div>

        <div class="cart-summary">
            <div class="row"><span>Total</span><span class="total"><?php echo format_price($grand_total); ?></span></div>
            <a href="checkout.php" class="btn block">Proceed to Checkout</a>
            <form method="post" action="cart_action.php" style="margin-top:10px;">
                <input type="hidden" name="action" value="clear">
                <button class="btn block outline" type="submit">Clear Cart</button>
            </form>
        </div>
    <?php endif; ?>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
