<?php
$page_title = 'Order Confirmed';
require_once __DIR__ . '/includes/header.php';
require_login();

$order_id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$res = mysqli_query($conn, "SELECT * FROM orders WHERE id = $order_id AND customer_id = " . (int)$_SESSION['customer_id']);
$order = mysqli_fetch_assoc($res);
if (!$order) redirect('index.php');
?>

<div class="container">
    <div class="form-box" style="text-align:center;">
        <h2>🎉 Order Placed Successfully!</h2>
        <p>Your order <strong>#<?php echo $order['id']; ?></strong> has been received and is <span class="badge badge-pending">pending</span>.</p>
        <p>Total: <strong><?php echo format_price($order['total']); ?></strong></p>
        <a href="orders.php" class="btn">View My Orders</a>
        <a href="index.php" class="btn outline" style="margin-left:8px;">Continue Shopping</a>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
