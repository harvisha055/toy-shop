<?php
$page_title = 'Dashboard';
require_once __DIR__ . '/includes/header.php';

$total_products = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM products"))['c'];
$total_orders = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM orders"))['c'];
$total_customers = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM customers"))['c'];
$total_revenue = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COALESCE(SUM(total),0) s FROM orders WHERE status != 'cancelled'"))['s'];
$pending_orders = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM orders WHERE status = 'pending'"))['c'];
$low_stock = mysqli_fetch_assoc(mysqli_query($conn, "SELECT COUNT(*) c FROM products WHERE stock < 10"))['c'];
?>

<div class="admin-topbar">
    <h1>Dashboard</h1>
    <span>Welcome, <?php echo htmlspecialchars($_SESSION['admin_username']); ?></span>
</div>

<div class="stat-cards">
    <div class="stat-card"><div class="num"><?php echo $total_products; ?></div><div class="label">Total Products</div></div>
    <div class="stat-card"><div class="num"><?php echo $total_orders; ?></div><div class="label">Total Orders</div></div>
    <div class="stat-card"><div class="num"><?php echo $total_customers; ?></div><div class="label">Registered Customers</div></div>
    <div class="stat-card"><div class="num"><?php echo format_price($total_revenue); ?></div><div class="label">Total Revenue</div></div>
    <div class="stat-card"><div class="num"><?php echo $pending_orders; ?></div><div class="label">Pending Orders</div></div>
    <div class="stat-card"><div class="num"><?php echo $low_stock; ?></div><div class="label">Low Stock Items (&lt;10)</div></div>
</div>

<h2>Recent Orders</h2>
<div class="table-responsive">
<table class="data-table">
    <thead><tr><th>Order #</th><th>Customer</th><th>Total</th><th>Status</th><th>Date</th></tr></thead>
    <tbody>
    <?php
    $recent = mysqli_query($conn, "SELECT o.*, c.name AS cust_name FROM orders o LEFT JOIN customers c ON o.customer_id = c.id ORDER BY o.created_at DESC LIMIT 8");
    while ($o = mysqli_fetch_assoc($recent)):
    ?>
        <tr>
            <td><a href="order_view.php?id=<?php echo $o['id']; ?>">#<?php echo $o['id']; ?></a></td>
            <td><?php echo htmlspecialchars($o['cust_name']); ?></td>
            <td><?php echo format_price($o['total']); ?></td>
            <td><span class="badge badge-<?php echo $o['status']; ?>"><?php echo $o['status']; ?></span></td>
            <td><?php echo date('M d, Y', strtotime($o['created_at'])); ?></td>
        </tr>
    <?php endwhile; ?>
    </tbody>
</table>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
