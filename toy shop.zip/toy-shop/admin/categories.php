<?php
$page_title = 'Categories';
require_once __DIR__ . '/includes/header.php';

if (isset($_GET['delete'])) {
    $id = (int)$_GET['delete'];
    mysqli_query($conn, "DELETE FROM categories WHERE id = $id");
    redirect('categories.php');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = clean($_POST['name'] ?? '');
    $edit_id = (int)($_POST['edit_id'] ?? 0);
    if ($name === '') {
        $error = 'Category name is required.';
    } elseif ($edit_id > 0) {
        $stmt = mysqli_prepare($conn, "UPDATE categories SET name = ? WHERE id = ?");
        mysqli_stmt_bind_param($stmt, 'si', $name, $edit_id);
        mysqli_stmt_execute($stmt);
        redirect('categories.php');
    } else {
        $stmt = mysqli_prepare($conn, "INSERT INTO categories (name) VALUES (?)");
        mysqli_stmt_bind_param($stmt, 's', $name);
        mysqli_stmt_execute($stmt);
        redirect('categories.php');
    }
}

$edit_cat = null;
if (isset($_GET['edit'])) {
    $res = mysqli_query($conn, "SELECT * FROM categories WHERE id = " . (int)$_GET['edit']);
    $edit_cat = mysqli_fetch_assoc($res);
}

$categories = mysqli_query($conn, "SELECT c.*, (SELECT COUNT(*) FROM products p WHERE p.category_id = c.id) AS product_count FROM categories c ORDER BY c.name");
?>

<div class="admin-topbar"><h1>Categories</h1></div>
<?php if ($error): ?><div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

<div style="display:flex; gap:30px; flex-wrap:wrap;">
    <form method="post" class="form-box" style="margin:0; max-width:320px;">
        <h2><?php echo $edit_cat ? 'Edit Category' : 'Add Category'; ?></h2>
        <input type="hidden" name="edit_id" value="<?php echo $edit_cat['id'] ?? 0; ?>">
        <div class="form-group">
            <label>Category Name</label>
            <input type="text" name="name" required value="<?php echo htmlspecialchars($edit_cat['name'] ?? ''); ?>">
        </div>
        <button class="btn block" type="submit"><?php echo $edit_cat ? 'Update' : 'Add'; ?></button>
        <?php if ($edit_cat): ?><a href="categories.php" class="btn block outline" style="margin-top:8px;">Cancel</a><?php endif; ?>
    </form>

    <div style="flex:1; min-width:300px;">
        <div class="table-responsive">
        <table class="data-table">
            <thead><tr><th>Name</th><th>Products</th><th>Actions</th></tr></thead>
            <tbody>
            <?php while ($c = mysqli_fetch_assoc($categories)): ?>
                <tr>
                    <td><?php echo htmlspecialchars($c['name']); ?></td>
                    <td><?php echo $c['product_count']; ?></td>
                    <td>
                        <a class="btn small" href="categories.php?edit=<?php echo $c['id']; ?>">Edit</a>
                        <a class="btn small danger" href="categories.php?delete=<?php echo $c['id']; ?>"
                           onclick="return confirm('Delete this category?');">Delete</a>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
        </div>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
