<?php
require_once __DIR__ . '/../../config/db.php';
require_once __DIR__ . '/../../config/functions.php';
require_admin();

$current = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo isset($page_title) ? $page_title . ' — Admin' : 'Admin — ToyBox'; ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
<!-- Mobile top bar -->
<div class="admin-mobile-bar d-lg-none">
    <button class="btn" type="button" data-bs-toggle="offcanvas" data-bs-target="#adminSidebar" aria-label="Open menu">
        &#9776;
    </button>
    <span class="brand">ToyBox Admin</span>
</div>

<div class="admin-wrap">
    <!-- Sidebar: offcanvas on mobile, static on desktop -->
    <aside class="admin-sidebar offcanvas-lg offcanvas-start" tabindex="-1" id="adminSidebar">
        <div class="offcanvas-header d-lg-none">
            <h2 class="mb-0">ToyBox Admin</h2>
            <button type="button" class="btn-close btn-close-white" data-bs-dismiss="offcanvas" data-bs-target="#adminSidebar" aria-label="Close"></button>
        </div>
        <h2 class="d-none d-lg-block">ToyBox Admin</h2>
        <a href="dashboard.php" class="<?php echo $current === 'dashboard.php' ? 'active' : ''; ?>">Dashboard</a>
        <a href="products.php" class="<?php echo $current === 'products.php' || $current === 'product_form.php' ? 'active' : ''; ?>">Products</a>
        <a href="categories.php" class="<?php echo $current === 'categories.php' ? 'active' : ''; ?>">Categories</a>
        <a href="orders.php" class="<?php echo $current === 'orders.php' || $current === 'order_view.php' ? 'active' : ''; ?>">Orders</a>
        <a href="customers.php" class="<?php echo $current === 'customers.php' ? 'active' : ''; ?>">Customers</a>
        <a href="../index.php" target="_blank">View Store &rarr;</a>
        <a href="logout.php">Logout</a>
    </aside>
    <main class="admin-main">
