<?php
$page_title = 'Product Form';
require_once __DIR__ . '/includes/header.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$product = ['id' => 0, 'name' => '', 'description' => '', 'price' => '', 'stock' => '', 'category_id' => '', 'image' => 'no-image.png', 'is_active' => 1];

if ($id > 0) {
    $res = mysqli_query($conn, "SELECT * FROM products WHERE id = $id");
    $found = mysqli_fetch_assoc($res);
    if ($found) $product = $found;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = clean($_POST['name'] ?? '');
    $description = clean($_POST['description'] ?? '');
    $price = (float)($_POST['price'] ?? 0);
    $stock = (int)($_POST['stock'] ?? 0);
    $category_id = (int)($_POST['category_id'] ?? 0);
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    $image = $product['image'];

    // Handle image upload
    if (!empty($_FILES['image']['name'])) {
        $allowed = ['jpg', 'jpeg', 'png', 'gif', 'webp'];
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        if (in_array($ext, $allowed)) {
            $new_name = uniqid('toy_') . '.' . $ext;
            $dest = __DIR__ . '/../assets/uploads/' . $new_name;
            if (move_uploaded_file($_FILES['image']['tmp_name'], $dest)) {
                $image = $new_name;
            }
        } else {
            $error = 'Invalid image format. Use jpg, png, gif, or webp.';
        }
    }

    if ($name === '' || $price <= 0) {
        $error = $error ?: 'Please provide a valid name and price.';
    }

    if (!$error) {
        if ($id > 0) {
            $stmt = mysqli_prepare($conn, "UPDATE products SET name=?, description=?, price=?, stock=?, category_id=?, image=?, is_active=? WHERE id=?");
            mysqli_stmt_bind_param($stmt, 'ssdiisii', $name, $description, $price, $stock, $category_id, $image, $is_active, $id);
        } else {
            $stmt = mysqli_prepare($conn, "INSERT INTO products (name, description, price, stock, category_id, image, is_active) VALUES (?,?,?,?,?,?,?)");
            mysqli_stmt_bind_param($stmt, 'ssdiisi', $name, $description, $price, $stock, $category_id, $image, $is_active);
        }
        if (mysqli_stmt_execute($stmt)) {
            redirect('products.php');
        } else {
            $error = 'Failed to save product.';
        }
    }
}

$categories = mysqli_query($conn, "SELECT * FROM categories ORDER BY name");
?>

<div class="admin-topbar">
    <h1><?php echo $id > 0 ? 'Edit Product' : 'Add Product'; ?></h1>
    <a href="products.php" class="btn outline">&larr; Back</a>
</div>

<?php if ($error): ?><div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>

<form method="post" enctype="multipart/form-data" class="form-box" style="max-width:600px; margin:0;">
    <div class="form-group">
        <label>Product Name *</label>
        <input type="text" name="name" required value="<?php echo htmlspecialchars($product['name']); ?>">
    </div>
    <div class="form-group">
        <label>Description</label>
        <textarea name="description"><?php echo htmlspecialchars($product['description']); ?></textarea>
    </div>
    <div class="form-group">
        <label>Category</label>
        <select name="category_id">
            <option value="0">-- None --</option>
            <?php while ($c = mysqli_fetch_assoc($categories)): ?>
                <option value="<?php echo $c['id']; ?>" <?php echo $product['category_id'] == $c['id'] ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($c['name']); ?>
                </option>
            <?php endwhile; ?>
        </select>
    </div>
    <div class="form-group">
        <label>Price *</label>
        <input type="number" step="0.01" min="0" name="price" required value="<?php echo htmlspecialchars($product['price']); ?>">
    </div>
    <div class="form-group">
        <label>Stock</label>
        <input type="number" min="0" name="stock" value="<?php echo htmlspecialchars($product['stock']); ?>">
    </div>
    <div class="form-group">
        <label>Product Image</label>
        <input type="file" name="image" accept="image/*">
        <img src="../assets/uploads/<?php echo htmlspecialchars($product['image']); ?>" onerror="this.src='https://placehold.co/80x80?text=Toy'" style="width:80px; margin-top:8px; border-radius:8px;">
    </div>
    <div class="form-group">
        <label><input type="checkbox" name="is_active" <?php echo $product['is_active'] ? 'checked' : ''; ?> style="width:auto;"> Active (visible in store)</label>
    </div>
    <button class="btn block" type="submit">Save Product</button>
</form>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
