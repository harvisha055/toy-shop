<?php
$page_title = 'Home';
require_once __DIR__ . '/includes/header.php';

// Filters
$cat_id = isset($_GET['cat']) ? (int)$_GET['cat'] : 0;
$search = isset($_GET['q']) ? clean($_GET['q']) : '';

$categories = mysqli_query($conn, "SELECT * FROM categories ORDER BY name");

$sql = "SELECT * FROM products WHERE is_active = 1";
if ($cat_id > 0) {
    $sql .= " AND category_id = " . $cat_id;
}
if ($search !== '') {
    $sql .= " AND (name LIKE '%$search%' OR description LIKE '%$search%')";
}
$sql .= " ORDER BY created_at DESC";
$products = mysqli_query($conn, $sql);
?>

<div class="hero">
    <h1>Welcome to ToyBox 🧸</h1>
    <p>Discover fun, safe, and educational toys for every age!</p>
</div>

<div class="container">
    <form method="get" style="margin-top:24px; display:flex; gap:10px; max-width:420px;">
        <input type="text" name="q" placeholder="Search toys..." value="<?php echo htmlspecialchars($search); ?>"
               style="flex:1; padding:10px 14px; border-radius:999px; border:1px solid #e4e4ef;">
        <?php if ($cat_id > 0): ?><input type="hidden" name="cat" value="<?php echo $cat_id; ?>"><?php endif; ?>
        <button class="btn" type="submit">Search</button>
    </form>

    <div class="category-bar">
        <a href="index.php" class="<?php echo $cat_id == 0 ? 'active' : ''; ?>">All Toys</a>
        <?php while ($c = mysqli_fetch_assoc($categories)): ?>
            <a href="index.php?cat=<?php echo $c['id']; ?>" class="<?php echo $cat_id == $c['id'] ? 'active' : ''; ?>">
                <?php echo htmlspecialchars($c['name']); ?>
            </a>
        <?php endwhile; ?>
    </div>

    <div class="product-grid">
        <?php if (mysqli_num_rows($products) === 0): ?>
            <p>No toys found. Try a different search or category.</p>
        <?php endif; ?>
        <?php while ($p = mysqli_fetch_assoc($products)): ?>
            <div class="product-card">
                <a href="product.php?id=<?php echo $p['id']; ?>">
                    <img src="assets/uploads/<?php echo htmlspecialchars($p['image']); ?>"
                         onerror="this.src='https://placehold.co/300x220?text=Toy'" alt="<?php echo htmlspecialchars($p['name']); ?>">
                </a>
                <div class="info">
                    <h3><a href="product.php?id=<?php echo $p['id']; ?>"><?php echo htmlspecialchars($p['name']); ?></a></h3>
                    <div class="price"><?php echo format_price($p['price']); ?></div>
                    <div class="stock"><?php echo $p['stock'] > 0 ? $p['stock'] . ' in stock' : 'Out of stock'; ?></div>
                    <form method="post" action="cart_action.php">
                        <input type="hidden" name="product_id" value="<?php echo $p['id']; ?>">
                        <input type="hidden" name="action" value="add">
                        <button class="btn block" type="submit" <?php echo $p['stock'] <= 0 ? 'disabled' : ''; ?>>
                            Add to Cart
                        </button>
                    </form>
                </div>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
