<?php
// ============================================
// Shared helper functions
// ============================================

function clean($str) {
    global $conn;
    return mysqli_real_escape_string($conn, trim($str));
}

function is_logged_in() {
    return isset($_SESSION['customer_id']);
}

function require_login() {
    if (!is_logged_in()) {
        header('Location: login.php');
        exit;
    }
}

function is_admin_logged_in() {
    return isset($_SESSION['admin_id']);
}

function require_admin() {
    if (!is_admin_logged_in()) {
        header('Location: login.php');
        exit;
    }
}

function cart_count() {
    if (!isset($_SESSION['cart']) || !is_array($_SESSION['cart'])) return 0;
    return array_sum($_SESSION['cart']);
}

function format_price($price) {
    return '&#8377;' . number_format((float)$price, 2);
}

function redirect($url) {
    header('Location: ' . $url);
    exit;
}
