<?php
// ============================================
// Database configuration
// Update these values to match your MySQL setup
// ============================================
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'toy_shop');

$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error());
}

mysqli_set_charset($conn, 'utf8mb4');

// Start session (used across the whole site)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Site base URL (relative) — used for links/redirects
define('SITE_URL', '');
