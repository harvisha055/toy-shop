<?php
require_once __DIR__ . '/config/db.php';
unset($_SESSION['customer_id']);
unset($_SESSION['customer_name']);
header('Location: index.php');
exit;
